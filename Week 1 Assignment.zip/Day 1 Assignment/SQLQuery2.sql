use [MyNewDatabase]
select * from [dbo].[Production]