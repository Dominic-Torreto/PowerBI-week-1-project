use [MyNewDatabase]
select * from [dbo].[Dimdate]