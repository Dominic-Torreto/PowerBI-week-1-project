use [MyNewDatabase]
select * from [dbo].[Shipped]